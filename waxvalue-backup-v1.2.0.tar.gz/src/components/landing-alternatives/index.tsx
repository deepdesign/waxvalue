// Landing Page Alternatives
// Each component represents a unique design approach with animations and modern styling

export { LandingHeroSplit4 } from './landing-hero-split-4'
export { LandingGradientWave } from './landing-gradient-wave'
